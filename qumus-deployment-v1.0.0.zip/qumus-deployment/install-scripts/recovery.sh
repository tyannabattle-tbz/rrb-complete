#!/bin/bash

# QUMUS AI Orchestration Platform - Recovery Script
# Version: 1.0.0
# Emergency Recovery and Rollback
# Canryn Production and its subsidiaries

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Recovery code validation
validate_recovery_code() {
    local code=$1
    local code_file="recovery-codes/active-codes.txt"
    
    if [ ! -f "$code_file" ]; then
        log_error "Recovery codes file not found"
        return 1
    fi
    
    if grep -q "^$code$" "$code_file"; then
        log_success "Recovery code validated"
        return 0
    else
        log_error "Invalid recovery code"
        return 1
    fi
}

# Backup current state
backup_current_state() {
    log_info "Creating backup of current state..."
    local backup_dir="backups/backup-$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$backup_dir"
    
    cp -r server "$backup_dir/" 2>/dev/null || true
    cp -r client "$backup_dir/" 2>/dev/null || true
    cp -r drizzle "$backup_dir/" 2>/dev/null || true
    cp .env.local "$backup_dir/" 2>/dev/null || true
    
    log_success "Backup created at $backup_dir"
    echo "$backup_dir"
}

# Restore from backup
restore_from_backup() {
    local backup_dir=$1
    
    if [ ! -d "$backup_dir" ]; then
        log_error "Backup directory not found: $backup_dir"
        return 1
    fi
    
    log_warning "Restoring from backup: $backup_dir"
    
    cp -r "$backup_dir/server" . 2>/dev/null || true
    cp -r "$backup_dir/client" . 2>/dev/null || true
    cp -r "$backup_dir/drizzle" . 2>/dev/null || true
    cp "$backup_dir/.env.local" . 2>/dev/null || true
    
    log_success "Restore completed"
}

# Clear cache and rebuild
clear_cache_rebuild() {
    log_info "Clearing cache and rebuilding..."
    
    rm -rf node_modules/.pnpm .next dist build 2>/dev/null || true
    pnpm install --frozen-lockfile
    pnpm build
    
    log_success "Cache cleared and rebuild completed"
}

# Database recovery
recover_database() {
    log_info "Recovering database..."
    
    log_warning "This will reset the database. Ensure you have backups."
    read -p "Continue? (yes/no): " confirm
    
    if [ "$confirm" != "yes" ]; then
        log_info "Database recovery cancelled"
        return 0
    fi
    
    pnpm db:push
    log_success "Database recovered"
}

# Component verification
verify_components() {
    log_info "Verifying all components..."
    
    local components=("server" "client" "drizzle" "package.json")
    local missing=0
    
    for component in "${components[@]}"; do
        if [ -e "$component" ]; then
            log_success "✓ $component found"
        else
            log_error "✗ $component missing"
            missing=$((missing + 1))
        fi
    done
    
    if [ $missing -eq 0 ]; then
        log_success "All components verified"
        return 0
    else
        log_error "$missing components missing"
        return 1
    fi
}

# Generate new recovery codes
generate_recovery_codes() {
    log_info "Generating new recovery codes..."
    
    local codes_file="recovery-codes/active-codes.txt"
    mkdir -p recovery-codes
    
    > "$codes_file"
    
    for i in {1..10}; do
        local code=$(openssl rand -hex 16)
        echo "$code" >> "$codes_file"
        echo "Code $i: $code"
    done
    
    log_success "Recovery codes generated and saved to $codes_file"
    log_warning "Store these codes in a secure location!"
}

# Main recovery menu
show_menu() {
    echo ""
    echo -e "${BLUE}QUMUS Recovery Menu${NC}"
    echo "1. Validate recovery code"
    echo "2. Backup current state"
    echo "3. Restore from backup"
    echo "4. Clear cache and rebuild"
    echo "5. Recover database"
    echo "6. Verify components"
    echo "7. Generate recovery codes"
    echo "8. Full system recovery"
    echo "9. Exit"
    echo ""
}

# Full system recovery
full_system_recovery() {
    log_warning "Starting full system recovery..."
    
    backup_current_state
    clear_cache_rebuild
    recover_database
    verify_components
    
    log_success "Full system recovery completed"
}

# Main function
main() {
    log_info "=========================================="
    log_info "QUMUS Recovery System v1.0.0"
    log_info "Canryn Production and its subsidiaries"
    log_info "=========================================="
    
    while true; do
        show_menu
        read -p "Select option (1-9): " choice
        
        case $choice in
            1)
                read -p "Enter recovery code: " code
                validate_recovery_code "$code"
                ;;
            2)
                backup_current_state
                ;;
            3)
                read -p "Enter backup directory path: " backup_path
                restore_from_backup "$backup_path"
                ;;
            4)
                clear_cache_rebuild
                ;;
            5)
                recover_database
                ;;
            6)
                verify_components
                ;;
            7)
                generate_recovery_codes
                ;;
            8)
                full_system_recovery
                ;;
            9)
                log_info "Exiting recovery system"
                exit 0
                ;;
            *)
                log_error "Invalid option"
                ;;
        esac
    done
}

main "$@"
