#!/bin/bash

# QUMUS AI Orchestration Platform - Master Installation Script
# Version: 1.0.0
# Production Deployment Package
# Canryn Production and its subsidiaries

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# System requirements check
check_requirements() {
    log_info "Checking system requirements..."
    
    # Check Node.js
    if ! command -v node &> /dev/null; then
        log_error "Node.js is not installed. Please install Node.js 20+ first."
        exit 1
    fi
    
    NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 20 ]; then
        log_error "Node.js version 20+ required. Current: $(node -v)"
        exit 1
    fi
    log_success "Node.js $(node -v) detected"
    
    # Check pnpm
    if ! command -v pnpm &> /dev/null; then
        log_warning "pnpm not found. Installing globally..."
        npm install -g pnpm
    fi
    log_success "pnpm $(pnpm -v) detected"
    
    # Check git
    if ! command -v git &> /dev/null; then
        log_error "Git is not installed. Please install Git first."
        exit 1
    fi
    log_success "Git $(git --version | cut -d' ' -f3) detected"
}

# Install dependencies
install_dependencies() {
    log_info "Installing project dependencies..."
    pnpm install --frozen-lockfile
    log_success "Dependencies installed"
}

# Setup environment
setup_environment() {
    log_info "Setting up environment variables..."
    
    if [ ! -f .env.local ]; then
        log_warning ".env.local not found. Creating from template..."
        cat > .env.local << 'EOF'
# QUMUS AI Orchestration Platform - Environment Configuration
# Database
DATABASE_URL=mysql://user:password@localhost:3306/qumus

# Authentication
JWT_SECRET=your-jwt-secret-key-here
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://manus.im/login

# Owner Information
OWNER_NAME=Your Name
OWNER_OPEN_ID=your-open-id

# Manus Built-in APIs
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your-api-key

# Frontend Configuration
VITE_FRONTEND_FORGE_API_KEY=your-frontend-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_APP_TITLE=Qumus AI Assistant
VITE_APP_LOGO=/qumus-icon-192.webp

# Analytics
VITE_ANALYTICS_ENDPOINT=https://manus-analytics.com/api/send
VITE_ANALYTICS_WEBSITE_ID=your-website-id

# Stripe (Optional)
STRIPE_SECRET_KEY=your-stripe-secret
VITE_STRIPE_PUBLISHABLE_KEY=your-stripe-publishable
STRIPE_WEBHOOK_SECRET=your-webhook-secret
EOF
        log_warning "Please update .env.local with your actual credentials"
    fi
    log_success "Environment configured"
}

# Run database migrations
setup_database() {
    log_info "Setting up database..."
    pnpm db:push
    log_success "Database migrations completed"
}

# Build project
build_project() {
    log_info "Building project..."
    pnpm build
    log_success "Project built successfully"
}

# Run tests
run_tests() {
    log_info "Running test suite..."
    pnpm test 2>&1 | tail -20 || log_warning "Some tests may have failed. Check logs for details."
    log_success "Test suite completed"
}

# Start development server
start_dev_server() {
    log_info "Starting development server..."
    log_info "Server will start on http://localhost:3000"
    pnpm dev
}

# Main installation flow
main() {
    log_info "=========================================="
    log_info "QUMUS AI Orchestration Platform"
    log_info "Installation Script v1.0.0"
    log_info "Canryn Production and its subsidiaries"
    log_info "=========================================="
    
    check_requirements
    install_dependencies
    setup_environment
    setup_database
    build_project
    run_tests
    
    log_success "=========================================="
    log_success "Installation completed successfully!"
    log_success "=========================================="
    log_info ""
    log_info "Next steps:"
    log_info "1. Update .env.local with your credentials"
    log_info "2. Run 'pnpm dev' to start development server"
    log_info "3. Visit http://localhost:3000 in your browser"
    log_info ""
    log_info "For production deployment, run: pnpm build && pnpm start"
}

main "$@"
