import { z } from "zod";
import { notifyOwner } from "./notification";
import { adminProcedure, publicProcedure, protectedProcedure, router } from "./trpc";

export const systemRouter = router({
  health: publicProcedure
    .input(
      z.object({
        timestamp: z.number().min(0, "timestamp cannot be negative"),
      })
    )
    .query(() => ({
      ok: true,
    })),

  notifyOwner: adminProcedure
    .input(
      z.object({
        title: z.string().min(1, "title is required"),
        content: z.string().min(1, "content is required"),
      })
    )
    .mutation(async ({ input }) => {
      const delivered = await notifyOwner(input);
      return {
        success: delivered,
      } as const;
    }),

  createSession: protectedProcedure
    .input(
      z.object({
        name: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      return {
        sessionId,
        userId: ctx.user.id,
        createdAt: new Date(),
        name: input.name || `Session ${new Date().toLocaleDateString()}`,
      };
    }),

  getSessions: protectedProcedure
    .query(async ({ ctx }) => {
      return [
        {
          sessionId: `session_${Date.now()}`,
          userId: ctx.user.id,
          createdAt: new Date(),
          name: 'Current Session',
        },
      ];
    }),

  getSession: protectedProcedure
    .input(z.object({ sessionId: z.string() }))
    .query(async ({ ctx, input }) => {
      return {
        sessionId: input.sessionId,
        userId: ctx.user.id,
        createdAt: new Date(),
        name: 'Session',
      };
    }),

  deleteSession: protectedProcedure
    .input(z.object({ sessionId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      return { success: true, sessionId: input.sessionId };
    }),
});
