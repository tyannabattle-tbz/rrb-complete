# QUMUS Recovery Codes

**CRITICAL: Store these codes in a secure location**

## Overview

Recovery codes are single-use authentication tokens that allow system administrators to perform emergency recovery operations on the QUMUS platform. Each code grants access to one recovery operation.

## Active Recovery Codes

See `active-codes.txt` for the complete list of valid recovery codes.

## Usage

To use a recovery code:

```bash
./recovery.sh
# Select option 1 (Validate recovery code)
# Enter the recovery code when prompted
```

## Code Management

- **Generation**: New codes are generated during system setup
- **Validation**: Each code is validated against the active codes list
- **Single-use**: Codes should be treated as single-use tokens
- **Rotation**: Generate new codes periodically for security

## Security Guidelines

1. **Storage**: Keep codes in a secure password manager or encrypted file
2. **Access**: Only authorized administrators should have access
3. **Sharing**: Never share codes via email or unsecured channels
4. **Backup**: Maintain offline backups of recovery codes
5. **Rotation**: Regenerate codes every 90 days

## Emergency Procedures

### Full System Recovery

If the system is completely compromised:

```bash
./recovery.sh
# Select option 8 (Full system recovery)
# Provide a valid recovery code when prompted
```

This will:
1. Create a backup of current state
2. Clear all caches
3. Rebuild the application
4. Reset the database
5. Verify all components

### Database Recovery

To recover the database only:

```bash
./recovery.sh
# Select option 5 (Recover database)
# Provide a valid recovery code when prompted
```

### Component Verification

To verify all system components are present:

```bash
./recovery.sh
# Select option 6 (Verify components)
```

## Troubleshooting

### Invalid Recovery Code

If you receive "Invalid recovery code" error:
1. Verify the code matches exactly (case-sensitive)
2. Check that the code hasn't been used already
3. Generate new codes if needed

### Recovery Failed

If recovery fails:
1. Check system logs for error details
2. Ensure sufficient disk space
3. Verify database connectivity
4. Contact support with error logs

## Support

For recovery assistance, contact:
- **Email**: support@canrynproduction.com
- **Phone**: Emergency support line
- **Documentation**: See DEPLOYMENT_GUIDE.md

---

**Canryn Production and its subsidiaries**
Last Updated: 2026-02-08
